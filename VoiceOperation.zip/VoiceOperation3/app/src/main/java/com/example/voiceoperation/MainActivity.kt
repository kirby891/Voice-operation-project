package com.example.voiceoperation

import android.app.SearchManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Locale
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private var inputText: EditText? = null
    private var resText: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        inputText = findViewById(R.id.inputText)
        resText = findViewById(R.id.resText)
        val outbutButton = findViewById<Button>(R.id.outbutButton)
        val voiceOperationFab = findViewById<FloatingActionButton>(R.id.voiceOperationFab)

        outbutButton.setOnClickListener {
            // Display input text in resText
            resText?.text = inputText?.text.toString()
        }

        voiceOperationFab.setOnClickListener {
            startVoiceRecognition()
        }
    }

    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.JAPANESE.toString())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...")
        }
        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Voice recognition is not supported on your device.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleSearch(query: String) {
        val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
        }
        if (searchIntent.resolveActivity(packageManager) != null) {
            startActivity(searchIntent)
        } else {
            Toast.makeText(this, "No app found to handle search requests.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleMap(location: String) {
        val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$location")).apply {
            setPackage("com.google.android.apps.maps") // Ensure Google Maps app is used
        }
        if (mapIntent.resolveActivity(packageManager) != null) {
            startActivity(mapIntent)
        } else {
            Toast.makeText(this, "Google Maps app is not installed.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleVoiceCommand(spokenText: String) {
        val searchPattern = Pattern.compile("調べて (.+)")
        val mapPattern = Pattern.compile("行きたい (.+)")

        val searchMatcher = searchPattern.matcher(spokenText)
        if (searchMatcher.find()) {
            val query = searchMatcher.group(1) // Extract the search query
            handleSearch(query)

        }

        val mapMatcher = mapPattern.matcher(spokenText)
        if (mapMatcher.find()) {
            val location = mapMatcher.group(1) // Extract the location
            handleMap(location)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.let { results ->
                val spokenText = results[0] // Get the first result
                Log.d("voiceResult", spokenText)
                resText?.text = spokenText
                handleVoiceCommand(spokenText) // Call the handleVoiceCommand with spokenText
            }
        }
    }

    companion object {
        private const val REQUEST_CODE_SPEECH_INPUT = 1
    }
}
